/*
Kalaman filter as "Probabilistic robotics page: 204"
*/

#include "ros/ros.h"
#include <ros/package.h>
#include <random>
#include <iostream>
#include <Eigen/Dense>
#include "simulator/Parameters.h"
#include "simulator/simulator_parameters.h"
#include "../utilities/simulator_structures.h"
#include "simulator/simulator_base.h"
#include <visualization_msgs/Marker.h>
#include <tf/transform_broadcaster.h>
#include "std_msgs/Float32MultiArray.h"
using namespace Eigen;

visualization_msgs::Marker arrow; 
parameters params;


Matrix3d q;            // Error del proceso 
Matrix3d r;            // Error de medicion  
Matrix3d p;            // Matriz de covarianza
Matrix3d H;            // Jacobiano de la funcion H
Vector3d x_;           // Vector de estado
Matrix3d s;            // s xD
Matrix3d k;            // ganancia de Kalman
Matrix3d I;           // Identity Matrix

typedef struct LandMark_ {
        float x; //Coordenada del robot x
        float y; //Coordenada del robot y
        float r; //Distancia del landmark al robot
        float t; //Angulo del landmark respecto al robot
} LandMark;

std::vector<LandMark> objs;
int swi;

void centroidsCallback(const std_msgs::Float32MultiArray::ConstPtr& centroides)
{
	int i = 0;
	LandMark aux;
	objs.clear();

	for(std::vector<float>::const_iterator it = centroides->data.begin(); it != centroides->data.end(); ++it)
	{	
		if( i == 0 )
		{
			aux.x = *it;
			i++;
		}
		else if ( i == 1 )
		{
			aux.y = *it;
			i++;
		}
		else if ( i == 2 )
		{
			aux.r = *it; /*****************Add noise ?********************/
			i ++;
		}
		else
		{
			aux.t = *it;
			if(aux.t > M_PI)
				aux.t -= 2*M_PI;
			if(aux.t < -M_PI)
				aux.t += 2*M_PI;
			objs.push_back( aux );
			i = 0;
		}	
	}
}


bool kalmanCallback(simulator::simulator_base::Request  &req ,simulator::simulator_base::Response &res)
{
	float theta;
	float dist;
	float angle_z_i_t_hat;
	Vector3d v; // Diference of measurment and predicted measurment
	Matrix3d vf;
	Vector3d z_i_t;
	Vector3d z_i_t_hat;

	
	if(req.new_simulation) // Restart variables for new estimation 
	{
		std::cout << "New simulator: " << "\n";
		r << 0.00001, 0, 0, 0, 0.0001, 0, 0, 0, 0.0001;
	    q << 0.00001, 0, 0, 0, 0.0001, 0, 0, 0, 0.0001;
		p << 0,0,0,0,0,0,0,0,0;
		ros::Duration(0.1).sleep();
		x_ << params.robot_x ,params.robot_y,params.robot_theta;
		if(x_(2) > M_PI) x_(2) -= 2 * M_PI;
		if(x_(2) < M_PI) x_(2) += 2 * M_PI;
		swi = 0;
	}

	if(swi == 0) // Prediction step
	{	
		swi = 1;
		std::cout << "Inicio: \n" << x_ << "\n ------\n";
	    theta = x_(2) + req.theta;
		x_(0) = x_(0) + req.distance * cos(theta) ;
		x_(1) = x_(1) + req.distance * sin(theta) ;
		x_(2) = theta; 
	    
	    vf <<  	1, 0, -req.distance * sin(theta), 0, 1,  req.distance * cos(theta), 0, 0,  1;
		p = vf * p * vf.transpose() + q;
		std::cout << "Fin prediccion x: \n" << x_ << "\n ------\n";
		std::cout << "Fin prediccion p: \n" << p << "\n ------\n";
		return true;
	}	
	else // Actualizacion
	{
		swi = 0;
	
		for(std::vector<LandMark>::const_iterator mj = objs.begin(); mj != objs.end(); ++mj)
		{	
			std::cout << "Centroide x y r t : \n" << mj->x << " , " << mj->y << " , " << mj->r << " , " << mj->t   << "\n ------\n";
			
			z_i_t << mj->r , mj->t ,0; // The real measurement
			
			std::cout << "z_i_t: \n" << z_i_t << "\n ------\n";
			
			// Calculo de las lecturas esperadas respecto a la posicion del robot obtenida en el paso de prediccion
				
				dist = pow( mj->x - x_(0),2 ) + pow( mj->y - x_(1) ,2); // Radicando de la de la distancia entre un landmark y el robot 

				// Angulo del landmark respecto al robot
				angle_z_i_t_hat  = atan2(mj->y - x_(1), mj->x - x_(0)) - x_(2);
			
				// Validacion para que el angulo obtenido siempre este entre pi y -pi
				if (angle_z_i_t_hat > M_PI)
					angle_z_i_t_hat -= 2*M_PI;
				if (angle_z_i_t_hat < -M_PI)
					angle_z_i_t_hat += 2*M_PI;

				// Vector de lecturas esperadas
				z_i_t_hat  << sqrt(dist), angle_z_i_t_hat, 0 ;

				std::cout << "z_i_t_hat: \n" << z_i_t_hat << "\n ------\n";
			
			// fin calculo de lecturas esperadas
			
			// El jacobiano de la funcion h() con respecto al robot	
			H << -( mj->x - x_(0) ) / sqrt(dist) , -( mj->y - x_(1) ) / sqrt(dist),0,
			 	  ( mj->y - x_(1) ) / dist, -( mj->x - x_(0) ) / dist,-1,
			 	  0,0,0; // this row is zero por que  la etiqueta del landmark no depende de la posicion del robot
			
			std::cout << "H: \n" << H << "\n ------\n";
			
			s = ( H * p * H.transpose() ) + r; // S xD
			
			std::cout << "S: \n" << s << "\n ------\n";

			k = p * H.transpose() * s.inverse(); // Ganancia de kalman
			
			std::cout << "K: \n"<<  k << "\n ------\n";

			v = z_i_t - z_i_t_hat;  // original menos lo esperadp_
			
			std::cout << "V: \n"<< v << "\n ------\n";
			
			x_ = x_ + (k*v); // Actualizacion vector de estado
			
			std::cout << "X: \n" << x_ << "\n ------\n";
			
			p = ( I - k * H ) * p; // Actualizacion matriz de covarianza
			
			std::cout << "P: \n" << p << "\n ------\n";

		}
		
		// Validacion para que el angulo obtenido siempre este entre pi y -pi
		if (x_(2) > M_PI)
			x_(2) -= 2*M_PI;
		if (x_(2) < -M_PI)
			x_(2) += 2*M_PI;

		// Arrow for visualization in rviz

		arrow.pose.position.x = x_(0);
		arrow.pose.position.y = x_(1);
		arrow.pose.position.z = 0;
		arrow.pose.orientation = tf::createQuaternionMsgFromYaw(x_(2));

		std::cout << "Prediccion Final: \n" << x_ << "\n ------\n";

		return true;
	}

}

void paramsCallback(const simulator::Parameters::ConstPtr& paramss)
{
	  params.robot_x             = paramss->robot_x   ;
	  params.robot_y             = paramss->robot_y   ;
	  params.robot_theta         = paramss->robot_theta   ;    
	  params.robot_radio         = paramss->robot_radio   ;    
	  params.robot_max_advance   = paramss->robot_max_advance   ;          
	  params.robot_turn_angle    = paramss->robot_turn_angle   ;         
	  params.laser_num_sensors   = paramss->laser_num_sensors   ;          
	  params.laser_origin        = paramss->laser_origin         ;     
	  params.laser_range         = paramss->laser_range   ;    
	  params.laser_value         = paramss->laser_value   ;    
	  strcpy(params.world_name ,paramss -> world_name.c_str());       
	  params.noise               = paramss->noise   ;   
	  params.run                 = paramss->run   ; 
	  params.light_x             = paramss->light_x;
	  params.light_y             = paramss->light_y;
	  params.behavior            = paramss->behavior; 
}

int main(int argc, char *argv[])
{
	ros::init(argc, argv, "kalman");
	ros::NodeHandle n;
	ros::Subscriber params_sub = n.subscribe("simulator_parameters_pub", 0, paramsCallback);
	ros::ServiceServer service = n.advertiseService("simulator_kalman_serv", kalmanCallback);
	ros::Publisher pubposition = n.advertise<visualization_msgs::Marker>("/position_from_kalman", 1);		
	ros::Subscriber centroids_sub = n.subscribe("simulator_centroids_pub", 0, centroidsCallback);

	arrow.header.frame_id = "/map";
    arrow.header.stamp = ros::Time::now();
	arrow.ns = "position_from_kalman";
	arrow.id = 0;

	arrow.type = visualization_msgs::Marker::ARROW;
	arrow.action = visualization_msgs::Marker::ADD;
	arrow.scale.x=.10;
	arrow.scale.y=.010;
	arrow.scale.z = .010;

	arrow.color.g = 0.0f;
	arrow.color.a = 1.0;
	arrow.color.r = 1.0f;
	arrow.color.b = 0.0f;

	I << 1,0,0,0,1,0,0,0,1;
	ros::Rate loop_rate(5);
	
	while (ros::ok())
	{
		pubposition.publish(arrow);
		ros::spinOnce();
		loop_rate.sleep();
	}

}