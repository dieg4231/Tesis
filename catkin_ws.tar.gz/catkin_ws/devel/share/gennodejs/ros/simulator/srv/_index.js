
"use strict";

let simulator_turtlebot = require('./simulator_turtlebot.js')
let simulator_object_interaction = require('./simulator_object_interaction.js')
let simulator_stop = require('./simulator_stop.js')
let simulator_robot_laser_values = require('./simulator_robot_laser_values.js')
let simulator_laser = require('./simulator_laser.js')
let simulator_set_light_position = require('./simulator_set_light_position.js')
let simulator_base = require('./simulator_base.js')
let simulator_algorithm_result = require('./simulator_algorithm_result.js')
let simulator_light = require('./simulator_light.js')
let simulator_robot_step = require('./simulator_robot_step.js')
let simulator_parameters = require('./simulator_parameters.js')

module.exports = {
  simulator_turtlebot: simulator_turtlebot,
  simulator_object_interaction: simulator_object_interaction,
  simulator_stop: simulator_stop,
  simulator_robot_laser_values: simulator_robot_laser_values,
  simulator_laser: simulator_laser,
  simulator_set_light_position: simulator_set_light_position,
  simulator_base: simulator_base,
  simulator_algorithm_result: simulator_algorithm_result,
  simulator_light: simulator_light,
  simulator_robot_step: simulator_robot_step,
  simulator_parameters: simulator_parameters,
};
