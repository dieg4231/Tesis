#!/bin/bash

 roslaunch simulator rviz_turtlebot.launch