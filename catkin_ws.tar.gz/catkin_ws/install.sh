#!/bin/bash
sudo apt-get  install ros-kinetic-turtlebot-*
sudo apt-get install libcgal-qt5-dev libcgal-dev 
find . -name "*.py" | xargs chmod +x



