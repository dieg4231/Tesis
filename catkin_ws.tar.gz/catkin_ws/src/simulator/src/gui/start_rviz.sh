#!/bin/bash

 roslaunch rob2w_description rviz.launch
